﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("AbpUserVerificationByEmail.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("AbpUserVerificationByEmail.TestBase")]
