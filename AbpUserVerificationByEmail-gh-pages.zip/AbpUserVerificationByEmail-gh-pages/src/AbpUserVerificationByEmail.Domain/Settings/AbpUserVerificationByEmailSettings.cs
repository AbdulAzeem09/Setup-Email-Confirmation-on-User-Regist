﻿namespace AbpUserVerificationByEmail.Settings;

public static class AbpUserVerificationByEmailSettings
{
    private const string Prefix = "AbpUserVerificationByEmail";

    //Add your own setting names here. Example:
    //public const string MySetting1 = Prefix + ".MySetting1";
}
