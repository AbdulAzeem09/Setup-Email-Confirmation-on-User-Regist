﻿namespace AbpUserVerificationByEmail;

public static class AbpUserVerificationByEmailConsts
{
    public const string DbTablePrefix = "App";

    public const string DbSchema = null;
}
