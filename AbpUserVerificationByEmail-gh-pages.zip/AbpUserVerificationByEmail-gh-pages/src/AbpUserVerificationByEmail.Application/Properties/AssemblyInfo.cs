﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("AbpUserVerificationByEmail.Application.Tests")]
