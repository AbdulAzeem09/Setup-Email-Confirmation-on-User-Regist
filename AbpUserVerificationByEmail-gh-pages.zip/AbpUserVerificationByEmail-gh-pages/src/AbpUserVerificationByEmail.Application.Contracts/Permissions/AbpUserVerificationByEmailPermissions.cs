﻿namespace AbpUserVerificationByEmail.Permissions;

public static class AbpUserVerificationByEmailPermissions
{
    public const string GroupName = "AbpUserVerificationByEmail";

    //Add your own permission names. Example:
    //public const string MyPermission1 = GroupName + ".MyPermission1";
}
