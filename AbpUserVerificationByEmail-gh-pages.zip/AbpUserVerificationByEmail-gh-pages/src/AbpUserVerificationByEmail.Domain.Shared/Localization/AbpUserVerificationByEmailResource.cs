﻿using Volo.Abp.Localization;

namespace AbpUserVerificationByEmail.Localization;

[LocalizationResourceName("AbpUserVerificationByEmail")]
public class AbpUserVerificationByEmailResource
{

}
