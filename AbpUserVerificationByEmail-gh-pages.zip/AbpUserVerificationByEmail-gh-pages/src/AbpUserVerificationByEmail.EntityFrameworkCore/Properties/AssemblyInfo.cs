﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("AbpUserVerificationByEmail.EntityFrameworkCore.Tests")]
