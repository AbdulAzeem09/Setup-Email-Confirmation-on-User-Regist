﻿using AutoMapper;

namespace AbpUserVerificationByEmail.Blazor;

public class AbpUserVerificationByEmailBlazorAutoMapperProfile : Profile
{
    public AbpUserVerificationByEmailBlazorAutoMapperProfile()
    {
        //Define your AutoMapper configuration here for the Blazor project.
    }
}
