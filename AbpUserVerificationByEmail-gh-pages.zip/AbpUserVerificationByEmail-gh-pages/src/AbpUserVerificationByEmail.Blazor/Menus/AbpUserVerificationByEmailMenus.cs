﻿namespace AbpUserVerificationByEmail.Blazor.Menus;

public class AbpUserVerificationByEmailMenus
{
    private const string Prefix = "AbpUserVerificationByEmail";
    public const string Home = Prefix + ".Home";

    //Add your menu items here...

}
