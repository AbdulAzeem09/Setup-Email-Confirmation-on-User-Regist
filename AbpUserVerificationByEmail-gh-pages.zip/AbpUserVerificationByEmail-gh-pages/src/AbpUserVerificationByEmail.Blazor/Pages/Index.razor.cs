﻿namespace AbpUserVerificationByEmail.Blazor.Pages;

public partial class Index
{

}
